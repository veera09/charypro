package com.capgemini.MPS.presentation;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.MPS.dao.MobilePurchaseSystemDAOimpl;
import com.capgemini.MPS.dto.MobilePurcahseSystemDTO;
import com.capgemini.MPS.exceptions.MobilePurchaseSystemException;
import com.capgemini.MPS.service.MobilePurchaseSystemImpl;
public class UI {
	private static Scanner in;
	static long currentid=1234001;
	static MobilePurchaseSystemImpl service= new MobilePurchaseSystemImpl();

	public static void main(String[] args) throws MobilePurchaseSystemException {
		in = new Scanner(System.in);
		System.out.println("Welocome To Mobile Regsitration Portal");
		String choice = "null";
		
		while (!choice.equals("4")) {
			System.out.println("Enter your choice");
			System.out.println("1) Insert Customer Details ");
			System.out.println("2) Display all mobiles and details");
			System.out.println("3) Search in range ");
			System.out.println("4) EXIT ");
			choice = in.next().trim();
			switch (choice) 
			{
			case "1": 
					getInputs();
					System.out.println("Thank you.... exited");
					break;
			case "2":
				System.out.println("The available mobiles are:");
				getMobileDetails();
				break;
			case "3": 
				searchMobile();
				break;	
		
			case "4":
				System.out.println("Thank you.... Program terminated");
				System.exit(0);
				break;
				
			default:
				System.out.println("WRONG CHOICE chosen...Please enter a valid choice");
			}
		}
		System.out.println("Thank you.... program terminated");
	}

	
	private static void getMobileDetails() throws MobilePurchaseSystemException {
		List<MobilePurcahseSystemDTO> mobilesList = new ArrayList<MobilePurcahseSystemDTO>();
		mobilesList = service.getAllMobiles();

		if (mobilesList != null) {
			Iterator<MobilePurcahseSystemDTO> i = mobilesList.iterator();
			
			while (i.hasNext()) {
				MobilePurcahseSystemDTO obj = (MobilePurcahseSystemDTO)i.next();
				System.out.print("MobileID:" + obj.getMobileId() +"  ");
				System.out.print("MobileName:" +obj.getMobileName() +"  ");
				System.out.print("MobilePrice:" +obj.getMobilePrice() +"  ");
				System.out.print("MobileQuantity:" +obj.getQuantity() +"  " + "\n");
			}
			System.out.println();
		} else {
			System.out.println("There are no mobiles in the store");
		}
	}

	
	private static void searchMobile() {
		// TODO Auto-generated method stub
		System.out.println("Enter Minimum price range");
		int min=in.nextInt();
		System.out.println("Enter Maximum price range");
		int max=in.nextInt();
		ArrayList<MobilePurcahseSystemDTO> sm = new ArrayList<MobilePurcahseSystemDTO>();
		sm = service.getSearchedMobiles(min, max);
		System.out.println("MobileID  MobileName  MobilePrice  MobileQuantity");
		if (sm != null) {
		Iterator<MobilePurcahseSystemDTO> i = sm.iterator();
		while (i.hasNext()) {
		MobilePurcahseSystemDTO obj = (MobilePurcahseSystemDTO) i.next();
		System.out.print(obj.getMobileId() + "  ");
		System.out.print(obj.getMobileName() + "  ");
		System.out.print(obj.getMobilePrice() + "  ");
		System.out.print(obj.getQuantity() + "  " + "\n");
		}
		System.out.println();
		} else {
		System.out.println("There are no mobiles in the store");
		}
		}
	
	
	
	

	private static void getInputs() throws MobilePurchaseSystemException {
		MobilePurcahseSystemDTO dtoOBJ = new MobilePurcahseSystemDTO();
		MobilePurchaseSystemDAOimpl daoOBJ = new MobilePurchaseSystemDAOimpl();
		MobilePurchaseSystemImpl serv= new MobilePurchaseSystemImpl();
		
		String customerName="?";
		String mailId="?";
		String phoneNumber="?";
		long mobId=0;
		Date purchaseDate=new Date();
		long purcahseId=0; 
		boolean status=true;
		int count=3;
		
		while(status)
		{
			System.out.println("Enter Customer Name");
			customerName=in.next();
			if(serv.validateName(customerName)==true)
			{
				status=true; break;
			}
			else
			{
			System.out.println("Name should start with captital letters.. enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		count=3;
		while(status)
		{
			System.out.println("Enter Customer Mail id");
			mailId=in.next();
			if(serv.validateEmail(mailId)==true){
				status=true; break;
			}
			else
			{
			System.out.println("Wrong mail id given.. enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		count=3;
		while(status)
		{
			System.out.println("Enter customer mobile number");
			phoneNumber=in.next();
			if(serv.validatePhoneNumber(phoneNumber)==true)
			{
				status=true; break;
			}
			else
			{
			System.out.println("Wrong mobile number given... Enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		count=3;
		while(status)
		{
			ArrayList<Long> list= new ArrayList<Long>();
			list = serv.getMobIds();
			
			System.out.println("Current avalialabe mobile ids are\n"+ list);
			System.out.println("enter mobile ID");
			mobId=in.nextLong();
			if(serv.validateMobileId(mobId)==true)
			{
				if(list.contains(mobId)){
				status=true; break;}
				else
				{
					System.out.println("Wrong Mobile id chosen... please select only available Ids");
				}
			}
			else
			{
			System.out.println("Wrong Mobile ID choosen.. enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		
		if(status==true)
		{
			purcahseId=currentid++;
			dtoOBJ.setCustomerName(customerName);
			dtoOBJ.setCustomerMailId(mailId); 
			dtoOBJ.setPhoneNumber(phoneNumber);
			dtoOBJ.setPurchaseDate(purchaseDate);
			dtoOBJ.setPurcahseId(purcahseId);
			dtoOBJ.setMobileId(mobId);
			
			dtoOBJ= serv.registerCustomer(dtoOBJ);
			System.out.println("\n****All details updated successfully*****");
			System.out.println("Your purchase ID is:" + serv.getPID());
		}
				else
			System.out.println("All details wrongly entered...\n");
	}
}
