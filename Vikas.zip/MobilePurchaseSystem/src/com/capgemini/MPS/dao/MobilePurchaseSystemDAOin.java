package com.capgemini.MPS.dao;

import java.util.ArrayList;

import com.capgemini.MPS.dto.MobilePurcahseSystemDTO;
import com.capgemini.MPS.exceptions.MobilePurchaseSystemException;

public interface MobilePurchaseSystemDAOin {

	public MobilePurcahseSystemDTO registerCustomer(MobilePurcahseSystemDTO daoObj) throws MobilePurchaseSystemException;
	public long getPID() throws MobilePurchaseSystemException;
	public ArrayList<Long> getMobIds() throws MobilePurchaseSystemException;
	public ArrayList<MobilePurcahseSystemDTO> getAllMobiles() throws MobilePurchaseSystemException;
}
