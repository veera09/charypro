package com.capgemini.MPS.dao;

public interface IQueryMapper {
	public static final String INSERT_QUERY="INSERT INTO purchasedetails values(MPS_sequence.nextval,?,?,?,?,?)";
	public static final String GET_PID="SELECT MPS_sequence.CURRVAL FROM DUAL";
	public static final String GET_MOBID="SELECT mobileid FROM mobiles";
	public static final String GET_ALLMOBILES="SELECT * FROM mobiles";
	public static final String GET_SEARCHED_MOBILES = "select * from mobiles where price between ? AND ?";
}
