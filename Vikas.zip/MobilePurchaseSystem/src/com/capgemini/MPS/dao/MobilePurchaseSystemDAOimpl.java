package com.capgemini.MPS.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.MPS.dto.MobilePurcahseSystemDTO;
import com.capgemini.MPS.exceptions.MobilePurchaseSystemException;
import com.capgemini.MPS.util.DBConnection;


public class MobilePurchaseSystemDAOimpl implements MobilePurchaseSystemDAOin 
{
	private Logger logger = Logger.getLogger(MobilePurchaseSystemDAOimpl.class);	
	public MobilePurchaseSystemDAOimpl()
	{
	PropertyConfigurator.configure("log4j.properties");
	}
	
	public MobilePurcahseSystemDTO registerCustomer(MobilePurcahseSystemDTO dtoObj) throws MobilePurchaseSystemException
	{
		logger.info("Customer registration started");
		Connection conn;
		PreparedStatement insertStmt = null;
		
		try
		{
			java.util.Date utilDate =dtoObj.getPurchaseDate();
			java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
			
			conn=DBConnection.getConnection();
			insertStmt=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1,dtoObj.getCustomerName());
			insertStmt.setString(2,dtoObj.getMailId());
			insertStmt.setString(3,dtoObj.getPhoneNumber());
			insertStmt.setDate(4,sqlDate);	
			insertStmt.setLong(5,dtoObj.getMobileId());
			int result = insertStmt.executeUpdate();
			
			if(result!=1)
			{
				logger.debug("value not inserted");
				throw new MobilePurchaseSystemException("sorry, cant process the request");
			}
			else
			{
				conn.commit();
			}
		}
		catch(MobilePurchaseSystemException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		return dtoObj;
	}
	
	

	public long getPID() throws MobilePurchaseSystemException
	{
		Connection conn;
		long val=0;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement=null;		
		
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_PID);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				val=resultSet.getLong(1);
			}
		}
		catch(MobilePurchaseSystemException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		return val;
	}
	
	
	public ArrayList<MobilePurcahseSystemDTO> getSearchedMobiles(int min, int max) {
		// TODO Auto-generated method stub

		ArrayList<MobilePurcahseSystemDTO> mlist = new ArrayList<MobilePurcahseSystemDTO>();
		Connection conn;
		PreparedStatement getSTMNT;

		try {
		conn = DBConnection.getConnection();
		getSTMNT = conn.prepareStatement(IQueryMapper.GET_SEARCHED_MOBILES);
		getSTMNT.setInt(1, min);
		getSTMNT.setInt(2, max);
		ResultSet set = getSTMNT.executeQuery();
		while (set.next()) {
		MobilePurcahseSystemDTO bin = new MobilePurcahseSystemDTO();
		bin.setMobileId(set.getInt(1));
		bin.setMobileName(set.getString(2));
		bin.setMobilePrice(set.getLong(3));
		bin.setQuantity(set.getInt(4));
		mlist.add(bin);
		}
		getSTMNT.close();
		} catch (Exception e) {
		System.out.println(e.getMessage());
		}

		return mlist;
		}


	
	
	
	
	
	
	
	public ArrayList<Long> getMobIds() throws MobilePurchaseSystemException
	{
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement=null;		
		ArrayList<Long> list= new ArrayList<Long>();
		
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_MOBID);
			resultSet=preparedStatement.executeQuery();

			while(resultSet.next())
			{
				list.add(resultSet.getLong("mobileid"));
			}
		}
		catch(MobilePurchaseSystemException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		return list;
	}
	
	
	public ArrayList<MobilePurcahseSystemDTO> getAllMobiles() throws MobilePurchaseSystemException
	{
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement=null;		
		ArrayList<MobilePurcahseSystemDTO> customerList= new ArrayList<MobilePurcahseSystemDTO>();
		
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_ALLMOBILES);
			resultSet=preparedStatement.executeQuery();

			while(resultSet.next())
			{	
				MobilePurcahseSystemDTO bean=new MobilePurcahseSystemDTO();
				bean.setMobileId(resultSet.getInt(1));
				bean.setMobileName(resultSet.getString(2));
				bean.setMobilePrice(resultSet.getInt(3));
				bean.setQuantity(resultSet.getInt(4));
				customerList.add(bean);	
			}	
		}
		
		catch(MobilePurchaseSystemException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		return customerList;
	}
	
	
}

