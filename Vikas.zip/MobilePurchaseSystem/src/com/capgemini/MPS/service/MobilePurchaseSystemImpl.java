package com.capgemini.MPS.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.capgemini.MPS.dao.MobilePurchaseSystemDAOimpl;
import com.capgemini.MPS.dto.MobilePurcahseSystemDTO;
import com.capgemini.MPS.exceptions.MobilePurchaseSystemException;

public class MobilePurchaseSystemImpl implements MobilePurchaseSystemService
{
	MobilePurchaseSystemDAOimpl mpDao;
	
	public MobilePurchaseSystemImpl()
	{
		mpDao = new MobilePurchaseSystemDAOimpl();
	}
	
	public MobilePurcahseSystemDTO registerCustomer(MobilePurcahseSystemDTO obj1) throws MobilePurchaseSystemException
	{
		return mpDao.registerCustomer(obj1);
	}
	
	public long getPID() throws MobilePurchaseSystemException
	{
		return mpDao.getPID();
	}
	
	public ArrayList<Long> getMobIds() throws MobilePurchaseSystemException
	{
		return mpDao.getMobIds();
	}
	
	public ArrayList<MobilePurcahseSystemDTO> getAllMobiles() throws MobilePurchaseSystemException
	{
		return mpDao.getAllMobiles();
	}
	
	
	public ArrayList<MobilePurcahseSystemDTO> getSearchedMobiles(int min, int max) {
		// TODO Auto-generated method stub
		return mpDao.getSearchedMobiles(min,max);
		}
	

	public boolean validateName(String str)
	{
    String namePattern = "[A-Z][A-Za-z ]{6,20}";
	if(Pattern.matches(namePattern,str))
	{
		return true;
	}
	else
	{
		return false;
	}
	}
	
	
	public boolean validateEmail(String str)
	{
		if(Pattern.matches("[A-Za-z0-9]{1,20}[@][A-Za-z]{3,15}[.][A-Za-z]{1,15}",str))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean validatePhoneNumber(String str)
	{
		if(Pattern.matches("\\d{10}",str))
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
	
	public boolean validateMobileId(long mobId)
	{
		String str = Long.toString(mobId);
	if(Pattern.matches("\\d{4}",str))
	{
		return true;
	}
	else
	{
		return false;
	}
	}
}
