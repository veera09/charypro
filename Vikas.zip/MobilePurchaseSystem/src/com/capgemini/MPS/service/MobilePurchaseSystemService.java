package com.capgemini.MPS.service;

import java.util.ArrayList;

import com.capgemini.MPS.dto.MobilePurcahseSystemDTO;
import com.capgemini.MPS.exceptions.MobilePurchaseSystemException;

public interface MobilePurchaseSystemService 
{
public boolean validateName(String str);
public boolean validateEmail(String str);
public boolean validatePhoneNumber(String str);
MobilePurcahseSystemDTO registerCustomer(MobilePurcahseSystemDTO obj1)
		throws MobilePurchaseSystemException;
public long getPID() throws MobilePurchaseSystemException;
public ArrayList<Long> getMobIds() throws MobilePurchaseSystemException;
public ArrayList<MobilePurcahseSystemDTO> getAllMobiles() throws MobilePurchaseSystemException;

}
