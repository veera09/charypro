package com.cg.lpa.exception;

public class LoanProcessingException extends Exception {
	public LoanProcessingException(String message) {
		super(message);
	}

	public LoanProcessingException() {

	}

}
